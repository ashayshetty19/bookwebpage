import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../shared/api.service';
import { novelmodel } from './novel.model';


@Component({
  selector: 'app-novel',
  templateUrl: './novel.component.html',
  styleUrls: ['./novel.component.css']
})
export class NovelComponent {
  formValue !: FormGroup;
  novelModeloBJ: novelmodel = new novelmodel();
  novelData: any;

  constructor(private formBuilder: FormBuilder, private api: ApiService, private router: Router) { }

  ngOnInit() {
    this.formValue = this.formBuilder.group({
      Tittle: [''],
      author: [''],
      genere: [''],
      firstpublished: [''],
      image: ['']
    });
    this.getAllnovels();

  }

  getAllnovels() {
    this.api.getNovels().subscribe(
      res => {
        this.novelData = res;
        console.log(res);
      });
  }
  fetchnov(nov:any) 
  { 
    this.router.navigate(['/novels', nov.image,nov.id, nov.Tittle, nov.author,nov.genere,nov.firstpublished]); 
    //console.log(nov.id+" "+nov.Tittle+" "+nov.author);
    
  }



}
