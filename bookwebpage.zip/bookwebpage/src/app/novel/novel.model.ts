export class novelmodel
{
    id:number=0;
    tittle:string='';
    author:string='';
    genere:string='';
    firstpublished:string='';


}