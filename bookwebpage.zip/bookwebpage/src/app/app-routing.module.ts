import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FetchdataComponent } from './fetchdata/fetchdata.component';
import { HomeComponent } from './home/home.component';
import { NovelComponent } from './novel/novel.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'novels', component: NovelComponent },
  { path: 'novels/:image/:id/:Tittle/:author/:genere/:firstpublished', component: FetchdataComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
