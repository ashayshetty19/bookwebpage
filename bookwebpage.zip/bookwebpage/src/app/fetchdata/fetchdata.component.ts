import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-fetchdata',
  templateUrl: './fetchdata.component.html',
  styleUrls: ['./fetchdata.component.css']
})
export class FetchdataComponent {
  public Id: any;
  public tittle:any;
  public author:any;
  public genere:any;
  public firstpublished:any;
  public image:any;
  constructor(private route: ActivatedRoute) {

  }
  ngOnInit() {
    let image = this.route.snapshot.paramMap.get('image');
    this.image = image;
    let id = this.route.snapshot.paramMap.get('id');
    console.log(this.route.snapshot.paramMap.get('id'+' is the id '));
    
    this.Id = id;
    let Tittle = this.route.snapshot.paramMap.get('Tittle');
    this.tittle = Tittle;
    let author = this.route.snapshot.paramMap.get('author');
    this.author= author;
    let genere = this.route.snapshot.paramMap.get('genere');
    this.genere = genere;
    let firstpublished = this.route.snapshot.paramMap.get('firstpublished');
    this.firstpublished= firstpublished;


  }




}
